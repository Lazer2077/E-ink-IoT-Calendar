#include <GxEPD.h>
// mapping suggestion from Waveshare SPI e-Paper to generic ESP8266
// BUSY -> D0, RST -> D1, DC -> D2, CS -> D8, CLK -> D5, DIN -> D7, GND -> GND, 3.3V -> 3.3V
#include <GxGDEW042T2/GxGDEW042T2.h>
#include WeatherIcons 
// FreeFonts from Adafruit_GFX
#include <Fonts/FreeMonoBold24pt7b.h>
#include <Fonts/FreeMonoBold18pt7b.h>
#include <Fonts/FreeMonoBold12pt7b.h>
#include <Fonts/FreeMonoBold9pt7b.h>
#include <Fonts/FreeMono9pt7b.h>
#include <Fonts/FreeSerifBoldItalic24pt7b.h>
#include <Fonts/FreeSerifBoldItalic12pt7b.h>
#include <Fonts/FreeSerifBold9pt7b.h>
#include <Fonts/FreeSans18pt7b.h>
#include <Fonts/FreeSans9pt7b.h> 
#include <Fonts/Org_01.h>


#include <GxIO/GxIO_SPI/GxIO_SPI.h>
#include <GxIO/GxIO.h>


GxIO_Class io(SPI, 15, 4, 5); 
GxEPD_Class display(io, 5, 16); 
